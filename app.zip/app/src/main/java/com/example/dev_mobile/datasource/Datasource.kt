package com.example.dev_mobile.datasource

import com.example.dev_mobile.model.Receita
class Datasource {

    companion object{
        fun getReceitas() : ArrayList<Receita>{
            var Receitas = ArrayList<Receita>()

            Receitas.add(Receita(1, "Macarrão", 5.0f, 20.toString()))
            Receitas.add(Receita(2, "Caipirinha", 4.0f, 5.toString()))
            Receitas.add(Receita(3, "Arroz Branco", 4.0f, 35.toString()))

            return Receitas
        }
    }
}