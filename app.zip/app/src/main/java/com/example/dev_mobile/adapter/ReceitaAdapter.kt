package com.example.dev_mobile.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dev_mobile.R
import com.example.dev_mobile.model.Receita
import kotlinx.android.synthetic.main.layout_lista_receita.view.*

class ReceitaAdapter(var listaReceita: ArrayList<Receita>) : RecyclerView.Adapter<ReceitaAdapter.ReceitaViewHolder>(){

    class ReceitaViewHolder (itemView : View) : RecyclerView.ViewHolder(itemView) {
        fun bind(receita: Receita) {
            itemView.textNomeDaReceita.text = receita.nomeReceita
            itemView.textConsole.text = receita.TempoPreparo
            itemView.notaReceita.rating = receita.notaReceita

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReceitaViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.layout_lista_receita, parent, false)
        return ReceitaViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return listaReceita.size
    }

    override fun onBindViewHolder(holder: ReceitaViewHolder, position: Int) {
        val receita = listaReceita[position]
        holder.bind(receita)
    }

}