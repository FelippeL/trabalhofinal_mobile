package com.example.dev_mobile.model

data class Receita(
    var codigo: Int,
    var nomeReceita: String,
    var notaReceita: Float,
    var TempoPreparo: String
)
